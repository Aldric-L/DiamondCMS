<div id="erreur404content">
  <h1>Oups !</h1>
  <h2>Cette page n'existe pas ou plus !</h2>
  <h3>Pour revenir à l'accueil, <a href="<?= LINK; ?>">Cliquez-ici !</a></h3>
  <br />
</div>
