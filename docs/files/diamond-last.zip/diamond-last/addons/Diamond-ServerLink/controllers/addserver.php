<?php 

$controleur_def->loadJSAddon(LINK  . "addons/Diamond-ServerLink/views/js/addserver.js");
$controleur_def->loadViewAddon(ROOT . "addons/Diamond-ServerLink/views/addServer.php", true, false, "Ajouter un serveur de jeu");