
<div class="request_depend" id="DSL-iframe-requestdepend">
</div>
<p style="display:none;" id="infos-servers" data-baselink="<?php echo LINK;?>" data-link="<?php echo LINK;?>api/serveurs/get/getInfos/"></p>
<h3 id="DSL-iframe-loader" style="display: block;" class="text-center bree-serif"><img src="<?php echo LINK;?>getimage/gif/-/ajax-loader" alt="loading" /> Chargement en cours...</h5>

<script>


</script>