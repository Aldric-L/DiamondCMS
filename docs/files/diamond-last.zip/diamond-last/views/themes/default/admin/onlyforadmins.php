<div id="page-wrapper">
    <div class="row">
        <div class="col-lg-12">
            <h1 class="page-header text-alert">Vous n'avez pas l'autorisation d'accéder à ces réglages</h1>
            <h5>Veuillez contacter un administrateur pour obtenir un grade plus élevé.</h5>
        </div>
    </div>
</div>