<?php global $c, $a; ?>   
<div id="nonify">
    <div id="nonifytext">
        <h1 class="title"><?php echo $title; ?></h1>
        <h4><?php echo $c; ?></h4>
        <p><em><?php echo $a; ?></em></p>
    </div>
</div>