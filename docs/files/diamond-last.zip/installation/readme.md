ATTENTION ! Ne pas supprimer ce dossier même après l'installation de DiamondCMS (ce dossier contient aussi des pages dites "d'urgence" pour portéger le site en cas de problèmes graves dans la config ou dans le CMS)

Veuillez noter que, pour des questions pratiques, ce dossier est le seul du CMS à ne pas respecter l'architecture MVC. 