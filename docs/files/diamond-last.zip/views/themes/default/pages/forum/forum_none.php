  <div id="emptyServer">
    <br />
    <h1>Erreur !</h1>
    <h2>Le Forum a été desactivé par l'administrateur !</h2>
    <br /><br /><br />
  </div><br /><br /><br />