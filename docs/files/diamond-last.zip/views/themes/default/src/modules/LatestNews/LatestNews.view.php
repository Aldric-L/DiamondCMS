<section id="LatestNews" data-link="<?= LINK . "api/tools/get/latestNews/"; ?>" data-baseLink="<?= LINK; ?>">
  <div class="container-fluid">
    <h1 class="text-center title">Actualités</h1>
    <p class="text-center">Decouvrez les nouveautés en rapport avec nos serveurs ! <a href="news/">Voir toutes les nouveautés...</a></p>
    <br />
    <div class="rows">
      <h3 id="loaderLN" style="display: block;" class="text-center title"><img src="<?= LINK; ?>getimage/gif/-/ajax-loader" alt="loading" /> Chargement en cours...</h5>
      <div id="LatestNewsRenderer"></div>
    </div>
  </div>
</section>