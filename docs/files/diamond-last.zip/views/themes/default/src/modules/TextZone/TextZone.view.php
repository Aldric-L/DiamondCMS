<section id="TextZone" class="content-editable-textZoneModule" data-apilink="<?php echo LINK . "API/"; ?>" data-page="<?php echo $this->mm_instance->getPageName();; ?>">
  <?php echo $content; ?>
</section>