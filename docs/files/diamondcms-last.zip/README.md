Bienvenue sur le dépot officiel de DiamondCMS.
Ici vous trouverez bien-sûr les sources et une documentation. Ne téléchargez pas tout le repository ! 

Téléchargez ce dossier compressé : https://aldric-l.github.io/DiamondCMS/files/diamondcms-last.zip


Documentation : https://github.com/Aldric-L/DiamondCMS/wiki

Lien pour accèder aux anciennes versions et aux dossiers de mise à jour (et ainsi accèder aux mises à jour en développement) : https://github.com/Aldric-L/DiamondCMS/tree/master/docs/files