<?php
/*
 * Extrait de : https://github.com/xPaw/PHP-Minecraft-Query
 * Licence MIT
 */
 
 namespace DServerLink\MinecraftQuery;

class MinecraftQueryException extends \Exception
{
	// Exception thrown by MinecraftQuery class
}