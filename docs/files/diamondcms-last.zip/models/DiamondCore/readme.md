Ceci est le noyau de DiamondCMS, nommé DiamondCore, qui est utilisé par tous les fichier du CMS.
Ce dernier est toutefois indépendant de DiamondCMS, et admet donc un numéro de version.

Version : 2.0 2020
Par Aldric L.