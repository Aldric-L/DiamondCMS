<div id="page-wrapper">
    <div class="row">
        <div class="col-lg-12">
            <h1 class="page-header">Gestion de la boutique</h1>
            <h5>Pour modifier ces paramètres, il est nécessaire d'activer préalablement la boutique en se rendant sur <a href="<?php echo $Serveur_Config['protocol']; ?>://<?= $_SERVER['HTTP_HOST']; ?><?=WEBROOT; ?>admin/boutique/">cette page</a></h5>
        </div>
    </div>
    <br>
</div>