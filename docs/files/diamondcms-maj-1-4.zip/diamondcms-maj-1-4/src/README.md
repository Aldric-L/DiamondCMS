Bienvenue sur le dépot de développement officiel de DiamondCMS.
Ici se trouvent les sources les plus actualisées possibles.

Attention : merci d'attendre les sorties des versions finales sur le github avant de mettre à jour ! Ces modifications sont encore en cours de travail et peuvent être instables. 