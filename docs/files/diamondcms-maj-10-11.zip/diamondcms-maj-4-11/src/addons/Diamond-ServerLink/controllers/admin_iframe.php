<?php 

$controleur_def->loadJSAddon(LINK  . "addons/Diamond-ServerLink/views/js/admin_iframe.js");
$controleur_def->loadViewAddon(ROOT . "addons/Diamond-ServerLink/views/admin_iframe.php", true, false, "DSL IFramer", true);
