Ceci est le noyau de DiamondCMS, nommé DiamondCore, qui est utilisé par tous les fichiers du CMS.
Ce dernier est toutefois indépendant de DiamondCMS, et admet donc un numéro de version.

Version : 4.0 2023
Par Aldric L.

CHANGELOG : 
- 4.0 : Ajout du cache, amélioration de Errors et patch des fonctions du Core, amélioration du controleur, ajout de la class ini pour la gestion de la config et support des exceptions
- 3.0 : Paradigme objet : simplification du système
- 2.1 : Gestionnaire de pages + Ajout de la fonction pour convertir les tailles de fichiers en unités lisibles