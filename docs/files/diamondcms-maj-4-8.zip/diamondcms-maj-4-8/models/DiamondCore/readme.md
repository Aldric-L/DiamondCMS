Ceci est le noyau de DiamondCMS, nommé DiamondCore, qui est utilisé par tous les fichiers du CMS.
Ce dernier est toutefois indépendant de DiamondCMS, et admet donc un numéro de version.

Version : 3.0 2020
Par Aldric L.

CHANGELOG : 
- 3.0 : Paradigme objet : simplification du système
- 2.1 : Gestionnaire de pages + Ajout de la fonction pour convertir les tailles de fichiers en unités lisibles