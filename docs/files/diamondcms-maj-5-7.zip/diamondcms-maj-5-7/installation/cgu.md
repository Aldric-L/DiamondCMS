Conformément aux licences du projet, nos conditions d'utilisation sont claires :
- Vous vous engagez à ne pas modifier DiamondCMS dans l'objectif de distribuer ces modifications dans un but lucratif ou non.
- Vous vous engagez à ne pas modifier le bas de page (footer), et à ne pas retirer le lien vers DiamondCMS.

Tout comportement ne respectant pas ces conditions générales d'utilisation et les licences pourrait entraîner des poursuites.

Veuillez aussi noter que DiamondCMS ne recueille aucune donnée personnelle, et est donc totalement respectueux de votre vie privée et de la législation française en matière de protection des données. 

Il est aussi rappelé que DiamondCMS n'est affilié à aucune organisation à but lucratif. 